#!/usr/bin/env python
#_*_coding:utf-8_*_

__all__ = [
	'type1',
	'type2',
	'type3A',
	'type3B',
	'type4',
	'type5',
	'type6A',
	'type6B',
	'type6C',
	'type7',
	'type8',
	'type9',
	'type10',
	'type11',
	'type12',
	'type13',
	'type14',
	'type15',
	'type16'
	]